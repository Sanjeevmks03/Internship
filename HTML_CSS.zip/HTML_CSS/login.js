
// window.localStorage;
localStorage.setItem("admin", "admin");
localStorage.setItem("vineetks", "vineetks");
localStorage.setItem("Sanjeev", "Sanjeev@beehyv");
localStorage.setItem("Nitish", "Nitish@beehyv");
document.getElementsById("error").innerHTML = "User or password is not correct";

function loginfunc() {
    let nm = document.getElementsById("name").value;
    let pw = document.getElementsById("pass").value;

    if (localStorage.getItem(nm) == null || localStorage.getItem(nm) == "") {
        document.getElementsById("error").innerHTML = "User does'nt exists";
    }
    else if (localStorage.getItem(nm) != passw) {
        document.getElementsById("error").innerHTML = "User or password is not correct";
    }
    else{
        window.location.href = "webpage.html";
    }
}

