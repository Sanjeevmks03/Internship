# import math
def sqre(x):
    return x**2

    
x=int(input("Enter any number:: "))
print(sqre(x))