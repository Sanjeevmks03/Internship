def func(x):
    if x%2==0: return "It is an even number"
    else: return "It is an odd number"


x=int(input("Enter any number:: "))
print(func(x))