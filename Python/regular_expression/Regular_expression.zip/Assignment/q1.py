import math

str=input("Enter any maths expression:: ")
print(eval(str))
