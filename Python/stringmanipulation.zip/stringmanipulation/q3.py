str="Hello, World"
print("first occurence of 'o' is at:: ",str.find('o'),'\n',"last occurrence of 'o' is at:: ",str.rfind('o'))
print("first occurence of ',' is at:: ",str.find(','),'\n',"last occurrence of ',' is at:: ",str.rfind(','))