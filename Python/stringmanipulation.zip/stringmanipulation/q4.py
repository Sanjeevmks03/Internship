str="hellohiihowwhere"
str2=str.replace(str[0],'$').replace('$',str[0],1)
print(str2)