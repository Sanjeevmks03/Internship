st="1"
print("number is {}".format(st))