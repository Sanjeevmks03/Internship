# f=open("A.txt","w")
for i in range(26):
    st=chr(65+i)
    open(f"{st}.txt","w")
    
