import itertools
str='ABCDE'
l=list(itertools.combinations(str,3))
print(l)