import math

def sroot(x):
    return math.sqrt(x)
def power(x,y):
    return pow(x,y)

print(power(3,4))
print(sroot(81))