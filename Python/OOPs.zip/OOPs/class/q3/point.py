class point:
    def __init__(self,a,b):
        self.x=a
        self.y=b
    