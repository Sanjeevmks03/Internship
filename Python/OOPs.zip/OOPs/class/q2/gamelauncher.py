import guessgame
class gamelauncher:
    def main():
        obj=guessgame.guessgame
        obj.startgame()

    if __name__=="__main__":
        main()


